from importing_modules import *

path = os.getcwd() + '/'
path_cda = os.getcwd() + '/'
user_train = False
user_predictOne = False
user_predictAll = False
user_fr = False
train_normexpr = None
labelinfo = None
skip = None
train_metadata = None
testsplit = None
rejection_cutoff = None
std_params = False
pred_normexpr = None
pred_metadata = None
layer_paths = None
frsplit = None